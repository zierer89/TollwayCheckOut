CrewRoot rough app prototype
Open index.html in a browser. For GitHub Pages, upload all files to the repository root and enable Pages from the main branch.
This prototype includes working navigation and a Daily Checkout that saves checklist state locally on the device.
